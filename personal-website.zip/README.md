# Personal Info Website

## Student Information
**Name:** JOHNEDELLE M. DEVERA  
**Course:** BSIT  
**Section:** SM 4101  
**Subject:** Platform Technologies  

---

## 📌 Project Description
This is a simple static website created using HTML and CSS. It displays basic personal information and is intended for GitHub project submission and learning web development.

---

## ✅ How to View
1. Download the project
2. Open `index.html` in any web browser
